/**
 * Admin service — wraps all /admin/* endpoints.
 * Every entity has full CRUD so views never call api.post inline.
 */
import { api } from "@/lib/api";
import { endpoints } from "@/lib/endpoints";
import {
  pickArray,
  pickObject,
  str,
  num,
  bool,
  id,
  type RawObject,
} from "@/lib/raw-response";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function unwrap(raw: unknown): RawObject {
  const obj = pickObject(raw);
  // Many endpoints wrap in { data: ... }
  if (obj.data && typeof obj.data === "object") return obj.data as RawObject;
  return obj;
}

function unwrapArray(raw: unknown): RawObject[] {
  const arr = pickArray(raw);
  if (arr.length > 0) return arr;
  // Try { data: [...] }
  const obj = raw as Record<string, unknown>;
  if (obj?.data && Array.isArray(obj.data)) return obj.data as RawObject[];
  return [];
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

export interface AdminDashboardStats {
  clients: number;
  categories: number;
  services: number;
  packages: number;
  aiModels: number;
  subscriptions: number;
  activeSubscriptions: number;
}

/**
 * Builds stats by running parallel count queries on the list endpoints.
 * /admin/dashboard-stats may not exist in all envs — this is resilient.
 */
export async function fetchAdminDashboardStats(): Promise<AdminDashboardStats> {
  const results = await Promise.allSettled([
    api.get<unknown>(endpoints.admin.users),
    api.get<unknown>(endpoints.admin.categories),
    api.get<unknown>(endpoints.admin.services),
    api.get<unknown>(endpoints.admin.packages),
    api.get<unknown>(endpoints.admin.aiModels),
    api.get<unknown>(endpoints.admin.subscriptions),
    api.get<unknown>(endpoints.admin.subscriptionsActive),
  ]);

  const count = (r: PromiseSettledResult<unknown>) =>
    r.status === "fulfilled" ? unwrapArray(r.value).length : 0;

  return {
    clients: count(results[0]),
    categories: count(results[1]),
    services: count(results[2]),
    packages: count(results[3]),
    aiModels: count(results[4]),
    subscriptions: count(results[5]),
    activeSubscriptions: count(results[6]),
  };
}

// ─── Users (admin user accounts) ─────────────────────────────────────────────

export interface AdminUser {
  id: string;
  nameAr?: string;
  nameEn?: string;
  name: string;
  email?: string;
  phone?: string;
  active?: boolean;
  mainAdmin?: boolean;
  clientId?: string;
  country?: string;
  city?: string;
  avatar?: string | null;
  createdAt?: string;
}

function mapUser(u: RawObject): AdminUser {
  const country = u.country as RawObject | undefined;
  const city = u.city as RawObject | undefined;
  return {
    id: id(u),
    nameAr: str(u, "name_ar"),
    nameEn: str(u, "name_en"),
    name: str(u, "name_en", "name_ar", "name") ?? "—",
    email: str(u, "email"),
    phone: str(u, "phone"),
    active: bool(u, "active"),
    mainAdmin: bool(u, "main_admin"),
    clientId: str(u, "client_id"),
    country:
      (country && str(country, "name_en", "name")) ?? str(u, "country_name"),
    city: (city && str(city, "name_en", "name")) ?? str(u, "city_name"),
    avatar: str(u, "avatar") ?? null,
    createdAt: str(u, "created_at"),
  };
}

export async function fetchAdminUsers(): Promise<AdminUser[]> {
  return unwrapArray(await api.get<unknown>(endpoints.admin.users)).map(
    mapUser
  );
}

export async function fetchAdminUserSingle(
  userId: string | number
): Promise<AdminUser> {
  return mapUser(
    unwrap(
      await api.get<unknown>(endpoints.admin.userSingle, {
        query: { id: userId },
      })
    )
  );
}

export interface AdminUserInput {
  name_ar: string;
  name_en: string;
  email: string;
  password?: string;
  phone?: string;
  active?: boolean;
  main_admin?: boolean;
  client_id?: string | number;
}

export async function createAdminUser(
  input: AdminUserInput
): Promise<AdminUser> {
  return mapUser(
    unwrap(await api.post<unknown>(endpoints.admin.userCreate, input))
  );
}

export async function updateAdminUser(
  userId: string | number,
  input: Partial<AdminUserInput>
): Promise<AdminUser> {
  return mapUser(
    unwrap(
      await api.post<unknown>(endpoints.admin.userUpdate, {
        id: userId,
        ...input,
      })
    )
  );
}

export async function deleteAdminUser(userId: string | number): Promise<void> {
  await api.post<unknown>(endpoints.admin.userDelete, { id: userId });
}

// ─── Categories ───────────────────────────────────────────────────────────────

export interface AdminCategory {
  id: string;
  nameAr?: string;
  nameEn?: string;
  description?: string;
  image?: string | null;
  active?: boolean;
}

function mapCategory(c: RawObject): AdminCategory {
  return {
    id: id(c),
    nameAr: str(c, "name_ar"),
    nameEn: str(c, "name_en", "name"),
    description: str(c, "description"),
    image: str(c, "image", "category_image") ?? null,
    active: bool(c, "active"),
  };
}

export async function fetchAdminCategories(): Promise<AdminCategory[]> {
  return unwrapArray(await api.get<unknown>(endpoints.admin.categories)).map(
    mapCategory
  );
}

export interface AdminCategoryInput {
  name_ar: string;
  name_en: string;
  description?: string;
  active?: boolean;
  category_image?: File | null;
}

export async function createAdminCategory(
  input: AdminCategoryInput
): Promise<AdminCategory> {
  const fd = new FormData();
  fd.append("name_ar", input.name_ar);
  fd.append("name_en", input.name_en);
  if (input.description) fd.append("description", input.description);
  fd.append("active", input.active !== false ? "1" : "0");
  if (input.category_image) fd.append("category_image", input.category_image);
  return mapCategory(
    unwrap(await api.post<unknown>(endpoints.admin.categoryCreate, fd))
  );
}

export async function updateAdminCategory(
  categoryId: string | number,
  input: Partial<AdminCategoryInput>
): Promise<AdminCategory> {
  const fd = new FormData();
  fd.append("id", String(categoryId));
  if (input.name_ar !== undefined) fd.append("name_ar", input.name_ar);
  if (input.name_en !== undefined) fd.append("name_en", input.name_en);
  if (input.description !== undefined)
    fd.append("description", input.description);
  if (input.active !== undefined) fd.append("active", input.active ? "1" : "0");
  if (input.category_image) fd.append("category_image", input.category_image);
  return mapCategory(
    unwrap(await api.post<unknown>(endpoints.admin.categoryUpdate, fd))
  );
}

export async function deleteAdminCategory(
  categoryId: string | number
): Promise<void> {
  await api.post<unknown>(endpoints.admin.categoryDelete, { id: categoryId });
}

// ─── Services ─────────────────────────────────────────────────────────────────

export interface AdminService {
  id: string;
  nameAr?: string;
  nameEn?: string;
  description?: string;
  price?: number;
  active?: boolean;
  requiresDrawing?: boolean;
}

function mapService(s: RawObject): AdminService {
  return {
    id: id(s),
    nameAr: str(s, "name_ar"),
    nameEn: str(s, "name_en", "name"),
    description: str(s, "description"),
    price: num(s, "price"),
    active: bool(s, "active"),
    requiresDrawing: bool(s, "requires_drawing"),
  };
}

export async function fetchAdminServices(): Promise<AdminService[]> {
  return unwrapArray(await api.get<unknown>(endpoints.admin.services)).map(
    mapService
  );
}

export interface AdminServiceInput {
  name_ar: string;
  name_en: string;
  description?: string;
  price?: number | string;
  active?: boolean;
}

export async function createAdminService(
  input: AdminServiceInput
): Promise<AdminService> {
  return mapService(
    unwrap(await api.post<unknown>(endpoints.admin.serviceCreate, input))
  );
}

export async function updateAdminService(
  serviceId: string | number,
  input: Partial<AdminServiceInput>
): Promise<AdminService> {
  return mapService(
    unwrap(
      await api.post<unknown>(endpoints.admin.serviceUpdate, {
        id: serviceId,
        ...input,
      })
    )
  );
}

export async function deleteAdminService(
  serviceId: string | number
): Promise<void> {
  await api.post<unknown>(endpoints.admin.serviceDelete, { id: serviceId });
}

// ─── Packages ─────────────────────────────────────────────────────────────────

export interface AdminPackage {
  id: string;
  nameAr?: string;
  nameEn?: string;
  descriptionAr?: string;
  descriptionEn?: string;
  price?: number;
  durationMonths?: number;
  maxCameras?: number;
  maxBranches?: number;
  categoryId?: string;
  categoryName?: string;
  serviceIds?: string[];
  serviceNames?: string[];
  active?: boolean;
}

function mapPackage(p: RawObject): AdminPackage {
  const category = p.category as RawObject | undefined;
  const services = Array.isArray(p.services) ? (p.services as RawObject[]) : [];
  return {
    id: id(p),
    nameAr: str(p, "name_ar"),
    nameEn: str(p, "name_en", "name"),
    descriptionAr: str(p, "description_ar"),
    descriptionEn: str(p, "description_en", "description"),
    price: num(p, "price"),
    durationMonths: num(p, "duration_months"),
    maxCameras: num(p, "max_cameras"),
    maxBranches: num(p, "max_branches"),
    categoryId: str(p, "category_id") ?? (category && id(category)),
    categoryName:
      (category && str(category, "name_en", "name")) ?? str(p, "category_name"),
    serviceIds: services.map((s) => id(s)).filter(Boolean),
    serviceNames: services
      .map((s) => str(s, "name_en", "name") ?? "")
      .filter(Boolean),
    active: bool(p, "active"),
  };
}

export async function fetchAdminPackages(): Promise<AdminPackage[]> {
  return unwrapArray(await api.get<unknown>(endpoints.admin.packages)).map(
    mapPackage
  );
}

export interface AdminPackageInput {
  name_ar: string;
  name_en: string;
  description_ar?: string;
  description_en?: string;
  price: number | string;
  duration_months: number | string;
  active?: boolean;
  category_id?: string | number;
  max_cameras?: number | string;
  max_branches?: number | string;
  "service_ids[]"?: (string | number)[];
}

export async function createAdminPackage(
  input: AdminPackageInput
): Promise<AdminPackage> {
  // Build FormData with service_ids[] array
  const fd = buildPackageFormData(input);
  return mapPackage(
    unwrap(await api.post<unknown>(endpoints.admin.packageCreate, fd))
  );
}

export async function updateAdminPackage(
  packageId: string | number,
  input: Partial<AdminPackageInput>
): Promise<AdminPackage> {
  const fd = buildPackageFormData(input);
  fd.append("id", String(packageId));
  return mapPackage(
    unwrap(await api.post<unknown>(endpoints.admin.packageUpdate, fd))
  );
}

export async function deleteAdminPackage(
  packageId: string | number
): Promise<void> {
  await api.post<unknown>(endpoints.admin.packageDelete, { id: packageId });
}

function buildPackageFormData(input: Partial<AdminPackageInput>): FormData {
  const fd = new FormData();
  const fields: (keyof AdminPackageInput)[] = [
    "name_ar",
    "name_en",
    "description_ar",
    "description_en",
    "price",
    "duration_months",
    "category_id",
    "max_cameras",
    "max_branches",
  ];
  fields.forEach((k) => {
    if (input[k] !== undefined) fd.append(k, String(input[k]));
  });
  if (input.active !== undefined) fd.append("active", input.active ? "1" : "0");
  (input["service_ids[]"] ?? []).forEach((sid, idx) => {
    fd.append(`service_ids[${idx}]`, String(sid));
  });
  return fd;
}

// ─── AI Models ────────────────────────────────────────────────────────────────

export interface AdminAiModel {
  id: string;
  name: string;
  version?: string;
  modelPath?: string;
  serviceIds?: string[];
  serviceNames?: string[];
  active?: boolean;
}

function mapAiModel(m: RawObject): AdminAiModel {
  const services = Array.isArray(m.services) ? (m.services as RawObject[]) : [];
  return {
    id: id(m),
    name: str(m, "name") ?? "—",
    version: str(m, "version"),
    modelPath: str(m, "model_path"),
    serviceIds: services.map((s) => id(s)).filter(Boolean),
    serviceNames: services
      .map((s) => str(s, "name_en", "name") ?? "")
      .filter(Boolean),
    active: bool(m, "active"),
  };
}

export async function fetchAdminAiModels(): Promise<AdminAiModel[]> {
  return unwrapArray(await api.get<unknown>(endpoints.admin.aiModels)).map(
    mapAiModel
  );
}

export interface AdminAiModelInput {
  name: string;
  version?: string;
  model_path?: string;
  active?: boolean;
  "service_ids[]"?: (string | number)[];
}

export async function createAdminAiModel(
  input: AdminAiModelInput
): Promise<AdminAiModel> {
  return mapAiModel(
    unwrap(
      await api.post<unknown>(
        endpoints.admin.aiModelCreate,
        buildAiModelBody(input)
      )
    )
  );
}

export async function updateAdminAiModel(
  modelId: string | number,
  input: Partial<AdminAiModelInput>
): Promise<AdminAiModel> {
  return mapAiModel(
    unwrap(
      await api.post<unknown>(endpoints.admin.aiModelUpdate, {
        id: modelId,
        ...buildAiModelBody(input),
      })
    )
  );
}

export async function deleteAdminAiModel(
  modelId: string | number
): Promise<void> {
  await api.post<unknown>(endpoints.admin.aiModelDelete, { id: modelId });
}

function buildAiModelBody(
  input: Partial<AdminAiModelInput>
): Record<string, unknown> {
  const body: Record<string, unknown> = {};
  if (input.name !== undefined) body.name = input.name;
  if (input.version !== undefined) body.version = input.version;
  if (input.model_path !== undefined) body.model_path = input.model_path;
  if (input.active !== undefined) body.active = input.active;
  (input["service_ids[]"] ?? []).forEach((sid, idx) => {
    body[`service_ids[${idx}]`] = sid;
  });
  return body;
}

// ─── Settings ─────────────────────────────────────────────────────────────────

export interface AdminSettings {
  raw: Record<string, string>; // key → value pairs from API
}

export async function fetchAdminSettings(): Promise<AdminSettings> {
  const raw = await api.get<unknown>(endpoints.admin.settings);
  const arr = unwrapArray(raw);
  // Settings come as [{ key, value }, ...] or as a flat object
  const result: Record<string, string> = {};
  if (arr.length > 0) {
    arr.forEach((item) => {
      const k = str(item, "key");
      const v = str(item, "value");
      if (k) result[k] = v ?? "";
    });
  } else {
    const obj = unwrap(raw);
    Object.entries(obj).forEach(([k, v]) => {
      if (typeof v === "string" || typeof v === "number") result[k] = String(v);
    });
  }
  return { raw: result };
}

export async function upsertAdminSetting(
  key: string,
  value: string
): Promise<void> {
  await api.post<unknown>(endpoints.admin.settingsUpsert, { key, value });
}

export async function upsertManyAdminSettings(
  pairs: { key: string; value: string }[]
): Promise<void> {
  const body: Record<string, string> = {};
  pairs.forEach(({ key, value }, idx) => {
    body[`settings[${idx}][key]`] = key;
    body[`settings[${idx}][value]`] = value;
  });
  await api.post<unknown>(endpoints.admin.settingsUpsertMany, body);
}

export async function fetchAdminPrivacyPolicy(): Promise<string> {
  const raw = await api.get<unknown>(endpoints.admin.settingsPrivacyPolicy);
  const obj = unwrap(raw);
  return str(obj, "privacy_policy", "content", "value") ?? "";
}

// ─── Subscriptions ────────────────────────────────────────────────────────────

export interface AdminSubscription {
  id: string;
  userName?: string;
  userEmail?: string;
  package?: string;
  packageId?: string;
  status?: string;
  startDate?: string;
  endDate?: string;
  daysRemaining?: number;
  price?: number;
  createdAt?: string;
}

function mapSubscription(s: RawObject): AdminSubscription {
  const user = (s.user ?? s.customer) as RawObject | undefined;
  const pkg = s.package as RawObject | undefined;
  return {
    id: id(s),
    userName:
      (user && str(user, "name_en", "name")) ??
      str(s, "user_name", "customer_name"),
    userEmail: (user && str(user, "email")) ?? str(s, "user_email"),
    package: (pkg && str(pkg, "name_en", "name")) ?? str(s, "package_name"),
    packageId: (pkg && id(pkg)) ?? str(s, "package_id"),
    status: str(s, "status"),
    startDate: str(s, "start_date", "starts_at"),
    endDate: str(s, "end_date", "ends_at"),
    daysRemaining: num(s, "days_remaining"),
    price: num(s, "price", "amount"),
    createdAt: str(s, "created_at"),
  };
}

export async function fetchAdminSubscriptions(): Promise<AdminSubscription[]> {
  return unwrapArray(await api.get<unknown>(endpoints.admin.subscriptions)).map(
    mapSubscription
  );
}

export async function fetchAdminActiveSubscriptions(): Promise<
  AdminSubscription[]
> {
  return unwrapArray(
    await api.get<unknown>(endpoints.admin.subscriptionsActive)
  ).map(mapSubscription);
}

export async function fetchAdminSubscriptionSingle(
  subId: string | number
): Promise<AdminSubscription> {
  return mapSubscription(
    unwrap(
      await api.get<unknown>(endpoints.admin.subscriptionSingle, {
        query: { id: subId },
      })
    )
  );
}

// ─── Countries ────────────────────────────────────────────────────────────────

export interface AdminCountry {
  id: string;
  nameAr?: string;
  nameEn?: string;
  code?: string;
}

function mapCountry(c: RawObject): AdminCountry {
  return {
    id: id(c),
    nameAr: str(c, "name_ar"),
    nameEn: str(c, "name_en", "name"),
    code: str(c, "code"),
  };
}

export async function fetchAdminCountries(): Promise<AdminCountry[]> {
  return unwrapArray(await api.get<unknown>(endpoints.admin.countries)).map(
    mapCountry
  );
}

export interface AdminCountryInput {
  name_ar: string;
  name_en: string;
  code?: string;
}

export async function createAdminCountry(
  input: AdminCountryInput
): Promise<AdminCountry> {
  return mapCountry(
    unwrap(await api.post<unknown>(endpoints.admin.countryCreate, input))
  );
}

export async function updateAdminCountry(
  cid: string | number,
  input: Partial<AdminCountryInput>
): Promise<AdminCountry> {
  return mapCountry(
    unwrap(
      await api.put<unknown>(
        (endpoints.admin.countryUpdate as (id: string | number) => string)(cid),
        input
      )
    )
  );
}

export async function deleteAdminCountry(cid: string | number): Promise<void> {
  await api.delete<unknown>(
    (endpoints.admin.countryDelete as (id: string | number) => string)(cid)
  );
}

// ─── Cities ───────────────────────────────────────────────────────────────────

export interface AdminCity {
  id: string;
  nameAr?: string;
  nameEn?: string;
  countryId?: string;
  countryName?: string;
  latitude?: number;
  longitude?: number;
}

function mapCity(c: RawObject): AdminCity {
  const country = c.country as RawObject | undefined;
  return {
    id: id(c),
    nameAr: str(c, "name_ar"),
    nameEn: str(c, "name_en", "name"),
    countryId: str(c, "country_id") ?? (country && id(country)),
    countryName:
      (country && str(country, "name_en", "name")) ?? str(c, "country_name"),
    latitude: num(c, "latitude"),
    longitude: num(c, "longitude"),
  };
}

export async function fetchAdminCities(
  countryId?: string | number
): Promise<AdminCity[]> {
  const query = countryId ? { country_id: countryId } : undefined;
  return unwrapArray(
    await api.get<unknown>(endpoints.admin.cities, { query })
  ).map(mapCity);
}

export interface AdminCityInput {
  country_id: string | number;
  name_ar: string;
  name_en: string;
  latitude?: number;
  longitude?: number;
}

export async function createAdminCity(
  input: AdminCityInput
): Promise<AdminCity> {
  return mapCity(
    unwrap(await api.post<unknown>(endpoints.admin.cityCreate, input))
  );
}

export async function updateAdminCity(
  cityId: string | number,
  input: Partial<AdminCityInput>
): Promise<AdminCity> {
  return mapCity(
    unwrap(
      await api.put<unknown>(
        (endpoints.admin.cityUpdate as (id: string | number) => string)(cityId),
        input
      )
    )
  );
}

export async function deleteAdminCity(cityId: string | number): Promise<void> {
  await api.delete<unknown>(
    (endpoints.admin.cityDelete as (id: string | number) => string)(cityId)
  );
}
