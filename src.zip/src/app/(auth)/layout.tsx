import type { Metadata } from "next";
import { Providers } from "@/components/Providers";
import "../globals.css";

export const metadata: Metadata = {
  title: "Dashboard",
  description: "Admin dashboard with AI services",
  icons: {
    icon: "/icon.svg",
    apple: "/icon-light-32x32.png",
  },
};

// Inline script runs synchronously before any paint — eliminates theme flash.
const themeScript = `
(function() {
  try {
    var t = localStorage.getItem('app.theme');
    var dark = t === 'dark' || (!t && window.matchMedia('(prefers-color-scheme: dark)').matches);
    if (dark) {
      document.documentElement.classList.add('dark');
      document.documentElement.style.colorScheme = 'dark';
    }
    var l = localStorage.getItem('app.lang');
    if (l === 'ar') {
      document.documentElement.lang = 'ar';
      document.documentElement.dir = 'rtl';
    }
  } catch(e) {}
})();
`;

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
    >
      <head suppressHydrationWarning>
        {/* Must be first in <head> to run before CSS/render */}
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Cairo:wght@400;500;600;700&display=swap"
        />
      </head>
      <body suppressHydrationWarning>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
